# Othello-AI

Run the following command to play the game:

make run-othello


# ------- Debug -------
In case the command does not work, follow the next steps:

Step 1: Install PyGame Library
    pip install pygame

Step 2: Run the game, after successfully installing PyGame:
    python3 game.py


